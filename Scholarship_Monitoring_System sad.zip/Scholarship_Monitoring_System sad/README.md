# Scholarship Monitoring System

## Project Structure

Scholarship_Monitoring_System/
├── CSS/
│   └── style.css
├── js/
│   ├── auth.js
│   ├── compliance.js
│   ├── dashboard.js
│   ├── reports.js
│   ├── requirements.js
│   ├── scholarships.js
│   ├── students.js
│   └── supabase.js
├── index.html
├── dashboard.html
├── students.html
├── scholarships.html
├── requirements.html
├── compliance.html
├── reports.html
├── supabase.sql
└── README.md

## Demo Accounts

Admin:
admin@school.com
admin123

Student:
student@school.com
student123

## Features

- Admin and Student login
- Dashboard
- Add, Update, Delete and Search Students
- Add, Update, Delete and Search Scholarships
- Add, Update and Delete Requirements
- Compliance monitoring
- Reports and printing
- LocalStorage persistence for browser testing
- Supabase SQL schema

## How to Run

1. Open the folder in VS Code.
2. Install/use Live Server.
3. Open `index.html` with Live Server.
4. Login using one of the demo accounts.

Note: The included `js/supabase.js` currently uses browser LocalStorage for immediate testing. The `supabase.sql` file provides the PostgreSQL/Supabase database schema for a real backend connection.
