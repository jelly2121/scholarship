// =====================================================
// auth.js - Admin / Student Login
// =====================================================

import {
  DEMO_ACCOUNTS,
  setCurrentUser,
  getCurrentUser
} from "./supabase.js";

const form = document.getElementById("loginForm");
const message = document.getElementById("loginMessage");

if (getCurrentUser()) {
  window.location.href = "dashboard.html";
}

form?.addEventListener("submit", function (event) {
  event.preventDefault();

  const email = document.getElementById("email").value.trim().toLowerCase();
  const password = document.getElementById("password").value;

  const account = DEMO_ACCOUNTS.find(
    user => user.email === email && user.password === password
  );

  if (!account) {
    message.textContent = "Invalid email or password.";
    message.style.color = "#d64545";
    return;
  }

  setCurrentUser({
    email: account.email,
    role: account.role,
    name: account.name,
    studentId: account.studentId
  });

  window.location.href = "dashboard.html";
});
