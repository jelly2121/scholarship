// =====================================================
// reports.js
// Scholarship monitoring report
// =====================================================

import {
  requireAdmin,
  store,
  goDashboard,
  escapeHtml
} from "./supabase.js";

const user = requireAdmin();
if (!user) throw new Error("Admin required.");

const table = document.getElementById("reportTable");

document.getElementById("backBtn").addEventListener("click", goDashboard);

function getStudentStatus(studentId) {
  const required = store.requirements.filter(item => item.required);

  if (!required.length) return "No required requirements";

  const completed = required.filter(requirement => {
    const record = store.compliance.find(
      item =>
        item.studentId === studentId &&
        item.requirementId === requirement.id
    );

    return record?.status === "Complete";
  });

  return completed.length === required.length
    ? "Compliant"
    : `${completed.length}/${required.length} Complete`;
}

function renderReport() {
  if (!store.students.length) {
    table.innerHTML =
      `<tr><td colspan="3">No students found.</td></tr>`;
    return;
  }

  table.innerHTML = store.students.map(student => {
    const scholarship = store.scholarships[0];

    return `
      <tr>
        <td>${escapeHtml(student.fullName)}</td>
        <td>${escapeHtml(scholarship?.name || "No scholarship")}</td>
        <td>${getStudentStatus(student.id)}</td>
      </tr>
    `;
  }).join("");
}

document.getElementById("refreshReport")
  .addEventListener("click", renderReport);

document.getElementById("printReport")
  .addEventListener("click", () => window.print());

renderReport();
