// =====================================================
// dashboard.js
// =====================================================

import {
  requireLogin,
  getCurrentUser,
  store,
  logout,
  escapeHtml
} from "./supabase.js";

const user = requireLogin();
if (!user) throw new Error("Login required.");

document.getElementById("currentUser").textContent =
  `${user.name} (${user.role})`;

document.getElementById("dashboardWelcome").textContent =
  `Welcome, ${user.name}!`;

document.getElementById("studentCount").textContent =
  user.role === "student" ? 1 : store.students.length;

document.getElementById("scholarshipCount").textContent =
  store.scholarships.length;

document.getElementById("requirementCount").textContent =
  store.requirements.length;

let complianceCount = store.compliance.length;

if (user.role === "student") {
  complianceCount = store.compliance.filter(
    item => item.studentId === user.studentId
  ).length;
}

document.getElementById("complianceCount").textContent = complianceCount;

document.getElementById("logoutBtn").addEventListener("click", logout);

document.querySelectorAll(".sidebar button[data-page]").forEach(button => {
  button.addEventListener("click", () => {
    window.location.href = button.dataset.page + ".html";
  });
});

if (user.role !== "admin") {
  document.querySelectorAll(".admin-only").forEach(element => {
    element.style.display = "none";
  });
}
