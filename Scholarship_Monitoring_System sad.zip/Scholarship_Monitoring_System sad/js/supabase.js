// =====================================================
// supabase.js
// Shared data, login/session and utility functions
// =====================================================

export const DEMO_ACCOUNTS = [
  {
    email: "admin@school.com",
    password: "admin123",
    role: "admin",
    name: "System Administrator",
    studentId: null
  },
  {
    email: "student@school.com",
    password: "student123",
    role: "student",
    name: "Juan Dela Cruz",
    studentId: "1"
  }
];

const defaults = {
  students: [
    {
      id: "1",
      studentNo: "2026-0001",
      fullName: "Juan Dela Cruz",
      course: "BSIT",
      yearLevel: "2",
      email: "student@school.com",
      contact: "09123456789"
    }
  ],
  scholarships: [
    {
      id: "1",
      name: "Academic Scholarship",
      provider: "School",
      amount: 10000,
      slots: 20,
      status: "Active"
    }
  ],
  requirements: [
    { id: "1", name: "Certificate of Enrollment", required: true },
    { id: "2", name: "Report Card", required: true },
    { id: "3", name: "Good Moral Certificate", required: false }
  ],
  compliance: []
};

function load(key) {
  try {
    const value = localStorage.getItem("sms_" + key);
    return value ? JSON.parse(value) : structuredClone(defaults[key]);
  } catch {
    return structuredClone(defaults[key]);
  }
}

export const store = {
  students: load("students"),
  scholarships: load("scholarships"),
  requirements: load("requirements"),
  compliance: load("compliance")
};

export function saveStore() {
  Object.entries(store).forEach(([key, value]) => {
    localStorage.setItem("sms_" + key, JSON.stringify(value));
  });
}

export function uid(prefix = "id") {
  return prefix + "_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8);
}

export function getCurrentUser() {
  try {
    return JSON.parse(sessionStorage.getItem("sms_user") || "null");
  } catch {
    return null;
  }
}

export function setCurrentUser(user) {
  sessionStorage.setItem("sms_user", JSON.stringify(user));
}

export function logout() {
  sessionStorage.removeItem("sms_user");
  window.location.href = "index.html";
}

export function requireLogin() {
  const user = getCurrentUser();

  if (!user) {
    window.location.href = "index.html";
    return null;
  }

  return user;
}

export function requireAdmin() {
  const user = requireLogin();

  if (!user) return null;

  if (user.role !== "admin") {
    alert("Admin access only.");
    window.location.href = "dashboard.html";
    return null;
  }

  return user;
}

export function goDashboard() {
  window.location.href = "dashboard.html";
}

export function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export function money(value) {
  return "₱" + Number(value || 0).toLocaleString("en-PH", {
    minimumFractionDigits: 2
  });
}

export function showMessage(element, message, type = "success") {
  if (!element) return;
  element.textContent = message;
  element.style.color = type === "error" ? "#d64545" : "#16804b";
}

saveStore();
