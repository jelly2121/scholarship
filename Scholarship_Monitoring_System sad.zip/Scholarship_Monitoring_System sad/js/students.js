// =====================================================
// students.js
// ADD / UPDATE / DELETE Students
// =====================================================

import {
  requireAdmin,
  store,
  saveStore,
  uid,
  goDashboard,
  escapeHtml,
  showMessage
} from "./supabase.js";

const user = requireAdmin();
if (!user) throw new Error("Admin required.");

const form = document.getElementById("studentForm");
const table = document.getElementById("studentTable");
const search = document.getElementById("searchStudent");
const message = document.getElementById("studentMessage");

let editingId = null;

document.getElementById("backBtn").addEventListener("click", goDashboard);

function renderStudents() {
  const query = search.value.trim().toLowerCase();

  const students = store.students.filter(student =>
    [
      student.studentNo,
      student.fullName,
      student.course,
      student.yearLevel,
      student.email,
      student.contact
    ]
      .join(" ")
      .toLowerCase()
      .includes(query)
  );

  if (!students.length) {
    table.innerHTML =
      `<tr><td colspan="7">No students found.</td></tr>`;
    return;
  }

  table.innerHTML = students.map(student => `
    <tr>
      <td>${escapeHtml(student.studentNo)}</td>
      <td>${escapeHtml(student.fullName)}</td>
      <td>${escapeHtml(student.course)}</td>
      <td>${escapeHtml(student.yearLevel)}</td>
      <td>${escapeHtml(student.email)}</td>
      <td>${escapeHtml(student.contact || "")}</td>
      <td class="actions">
        <button class="edit" data-action="edit" data-id="${student.id}">Edit</button>
        <button class="delete" data-action="delete" data-id="${student.id}">Delete</button>
      </td>
    </tr>
  `).join("");
}

function resetForm() {
  editingId = null;
  form.reset();
  document.getElementById("formTitle").textContent = "Add Student";
  document.getElementById("cancelEdit").classList.add("hidden");
}

function editStudent(id) {
  const student = store.students.find(item => item.id === id);
  if (!student) return;

  editingId = id;

  document.getElementById("studentNo").value = student.studentNo;
  document.getElementById("fullName").value = student.fullName;
  document.getElementById("course").value = student.course;
  document.getElementById("yearLevel").value = student.yearLevel;
  document.getElementById("email").value = student.email;
  document.getElementById("contact").value = student.contact || "";

  document.getElementById("formTitle").textContent = "Update Student";
  document.getElementById("cancelEdit").classList.remove("hidden");

  window.scrollTo({ top: 0, behavior: "smooth" });
}

function deleteStudent(id) {
  const student = store.students.find(item => item.id === id);
  if (!student) return;

  if (!confirm(`Delete ${student.fullName}?`)) return;

  store.students = store.students.filter(item => item.id !== id);

  // Also remove related compliance records.
  store.compliance = store.compliance.filter(
    item => item.studentId !== id
  );

  saveStore();
  renderStudents();
  showMessage(message, "Student deleted successfully.");
}

table.addEventListener("click", event => {
  const button = event.target.closest("button");
  if (!button) return;

  const id = button.dataset.id;

  if (button.dataset.action === "edit") {
    editStudent(id);
  }

  if (button.dataset.action === "delete") {
    deleteStudent(id);
  }
});

form.addEventListener("submit", event => {
  event.preventDefault();

  const studentNo = document.getElementById("studentNo").value.trim();
  const fullName = document.getElementById("fullName").value.trim();
  const course = document.getElementById("course").value.trim();
  const yearLevel = document.getElementById("yearLevel").value.trim();
  const email = document.getElementById("email").value.trim();
  const contact = document.getElementById("contact").value.trim();

  if (!studentNo || !fullName || !course || !yearLevel || !email) {
    showMessage(message, "Please complete all required fields.", "error");
    return;
  }

  const duplicate = store.students.some(student =>
    student.studentNo.toLowerCase() === studentNo.toLowerCase() &&
    student.id !== editingId
  );

  if (duplicate) {
    showMessage(message, "Student ID already exists.", "error");
    return;
  }

  const student = {
    id: editingId || uid("student"),
    studentNo,
    fullName,
    course,
    yearLevel,
    email,
    contact
  };

  if (editingId) {
    const index = store.students.findIndex(item => item.id === editingId);
    store.students[index] = student;
    showMessage(message, "Student updated successfully.");
  } else {
    store.students.push(student);
    showMessage(message, "Student added successfully.");
  }

  saveStore();
  resetForm();
  renderStudents();
});

document.getElementById("cancelEdit").addEventListener("click", resetForm);
search.addEventListener("input", renderStudents);

renderStudents();
