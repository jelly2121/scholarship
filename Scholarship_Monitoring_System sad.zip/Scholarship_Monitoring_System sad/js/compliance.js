// =====================================================
// compliance.js
// View and update student compliance
// =====================================================

import {
  requireLogin,
  store,
  saveStore,
  uid,
  goDashboard,
  escapeHtml
} from "./supabase.js";

const user = requireLogin();
if (!user) throw new Error("Login required.");

const table = document.getElementById("complianceTable");

document.getElementById("backBtn").addEventListener("click", goDashboard);

function getStudents() {
  if (user.role === "admin") return store.students;

  return store.students.filter(
    student => student.id === user.studentId
  );
}

function renderCompliance() {
  const students = getStudents();
  const rows = [];

  students.forEach(student => {
    store.requirements.forEach(requirement => {
      let record = store.compliance.find(
        item =>
          item.studentId === student.id &&
          item.requirementId === requirement.id
      );

      const status = record?.status || "Pending";

      rows.push(`
        <tr>
          <td>${escapeHtml(student.fullName)}</td>
          <td>${escapeHtml(requirement.name)}</td>
          <td>${status}</td>
          <td>
            ${
              user.role === "admin"
                ? `<button
                    class="${status === "Complete" ? "delete" : "approve"}"
                    data-student="${student.id}"
                    data-requirement="${requirement.id}">
                    ${status === "Complete" ? "Mark Pending" : "Mark Complete"}
                   </button>`
                : "View only"
            }
          </td>
        </tr>
      `);
    });
  });

  table.innerHTML = rows.length
    ? rows.join("")
    : `<tr><td colspan="4">No compliance records found.</td></tr>`;
}

table.addEventListener("click", event => {
  const button = event.target.closest("button");
  if (!button || user.role !== "admin") return;

  const studentId = button.dataset.student;
  const requirementId = button.dataset.requirement;

  let record = store.compliance.find(
    item =>
      item.studentId === studentId &&
      item.requirementId === requirementId
  );

  if (!record) {
    record = {
      id: uid("compliance"),
      studentId,
      requirementId,
      status: "Complete"
    };
    store.compliance.push(record);
  } else {
    record.status =
      record.status === "Complete" ? "Pending" : "Complete";
  }

  saveStore();
  renderCompliance();
});

renderCompliance();
