// =====================================================
// requirements.js
// ADD / UPDATE / DELETE Requirements
// =====================================================

import {
  requireLogin,
  store,
  saveStore,
  uid,
  goDashboard,
  escapeHtml,
  showMessage
} from "./supabase.js";

const user = requireLogin();
if (!user) throw new Error("Login required.");

const form = document.getElementById("requirementForm");
const table = document.getElementById("requirementTable");
const message = document.getElementById("message");

let editingId = null;

document.getElementById("backBtn").addEventListener("click", goDashboard);

if (user.role !== "admin") {
  form.style.display = "none";
}

function renderRequirements() {
  if (!store.requirements.length) {
    table.innerHTML =
      `<tr><td colspan="3">No requirements found.</td></tr>`;
    return;
  }

  table.innerHTML = store.requirements.map(item => `
    <tr>
      <td>${escapeHtml(item.name)}</td>
      <td>${item.required ? "Required" : "Optional"}</td>
      <td class="actions">
        ${
          user.role === "admin"
            ? `<button class="edit" data-action="edit" data-id="${item.id}">Edit</button>
               <button class="delete" data-action="delete" data-id="${item.id}">Delete</button>`
            : "View only"
        }
      </td>
    </tr>
  `).join("");
}

function resetForm() {
  editingId = null;
  form.reset();
  document.querySelector("#requirementForm button").textContent = "Save";
}

function editRequirement(id) {
  const item = store.requirements.find(r => r.id === id);
  if (!item) return;

  editingId = id;
  document.getElementById("requirementName").value = item.name;
  document.getElementById("required").value = String(item.required);
  document.querySelector("#requirementForm button").textContent = "Update";
}

function deleteRequirement(id) {
  const item = store.requirements.find(r => r.id === id);
  if (!item) return;

  if (!confirm(`Delete "${item.name}"?`)) return;

  store.requirements = store.requirements.filter(r => r.id !== id);
  store.compliance = store.compliance.filter(
    c => c.requirementId !== id
  );

  saveStore();
  renderRequirements();
  showMessage(message, "Requirement deleted successfully.");
}

table.addEventListener("click", event => {
  const button = event.target.closest("button");
  if (!button || user.role !== "admin") return;

  if (button.dataset.action === "edit") {
    editRequirement(button.dataset.id);
  }

  if (button.dataset.action === "delete") {
    deleteRequirement(button.dataset.id);
  }
});

form.addEventListener("submit", event => {
  event.preventDefault();

  if (user.role !== "admin") return;

  const name = document.getElementById("requirementName").value.trim();
  const required = document.getElementById("required").value === "true";

  if (!name) {
    showMessage(message, "Requirement name is required.", "error");
    return;
  }

  const item = {
    id: editingId || uid("requirement"),
    name,
    required
  };

  if (editingId) {
    const index = store.requirements.findIndex(r => r.id === editingId);
    store.requirements[index] = item;
    showMessage(message, "Requirement updated successfully.");
  } else {
    store.requirements.push(item);
    showMessage(message, "Requirement added successfully.");
  }

  saveStore();
  resetForm();
  renderRequirements();
});

renderRequirements();
