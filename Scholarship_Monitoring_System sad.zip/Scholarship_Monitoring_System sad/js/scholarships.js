// =====================================================
// scholarships.js
// ADD / UPDATE / DELETE Scholarships
// =====================================================

import {
  requireAdmin,
  store,
  saveStore,
  uid,
  goDashboard,
  escapeHtml,
  money,
  showMessage
} from "./supabase.js";

const user = requireAdmin();
if (!user) throw new Error("Admin required.");

const form = document.getElementById("scholarshipForm");
const table = document.getElementById("scholarshipTable");
const search = document.getElementById("searchScholarship");
const message = document.getElementById("message");

let editingId = null;

document.getElementById("backBtn").addEventListener("click", goDashboard);

function renderScholarships() {
  const query = search.value.trim().toLowerCase();

  const scholarships = store.scholarships.filter(item =>
    [item.name, item.provider, item.status]
      .join(" ")
      .toLowerCase()
      .includes(query)
  );

  if (!scholarships.length) {
    table.innerHTML =
      `<tr><td colspan="6">No scholarships found.</td></tr>`;
    return;
  }

  table.innerHTML = scholarships.map(item => `
    <tr>
      <td>${escapeHtml(item.name)}</td>
      <td>${escapeHtml(item.provider)}</td>
      <td>${money(item.amount)}</td>
      <td>${item.slots}</td>
      <td>${escapeHtml(item.status)}</td>
      <td class="actions">
        <button class="edit" data-action="edit" data-id="${item.id}">Edit</button>
        <button class="delete" data-action="delete" data-id="${item.id}">Delete</button>
      </td>
    </tr>
  `).join("");
}

function resetForm() {
  editingId = null;
  form.reset();
  document.getElementById("formTitle").textContent = "Add Scholarship";
  document.getElementById("cancelEdit").classList.add("hidden");
}

function editScholarship(id) {
  const item = store.scholarships.find(s => s.id === id);
  if (!item) return;

  editingId = id;
  document.getElementById("scholarshipName").value = item.name;
  document.getElementById("provider").value = item.provider;
  document.getElementById("amount").value = item.amount;
  document.getElementById("slots").value = item.slots;
  document.getElementById("status").value = item.status;

  document.getElementById("formTitle").textContent = "Update Scholarship";
  document.getElementById("cancelEdit").classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function deleteScholarship(id) {
  const item = store.scholarships.find(s => s.id === id);
  if (!item) return;

  if (!confirm(`Delete "${item.name}"?`)) return;

  store.scholarships = store.scholarships.filter(s => s.id !== id);
  saveStore();
  renderScholarships();
  showMessage(message, "Scholarship deleted successfully.");
}

table.addEventListener("click", event => {
  const button = event.target.closest("button");
  if (!button) return;

  if (button.dataset.action === "edit") {
    editScholarship(button.dataset.id);
  }

  if (button.dataset.action === "delete") {
    deleteScholarship(button.dataset.id);
  }
});

form.addEventListener("submit", event => {
  event.preventDefault();

  const name = document.getElementById("scholarshipName").value.trim();
  const provider = document.getElementById("provider").value.trim();
  const amount = Number(document.getElementById("amount").value);
  const slots = Number(document.getElementById("slots").value);
  const status = document.getElementById("status").value;

  if (!name || !provider || amount < 0 || slots < 1) {
    showMessage(message, "Please enter valid scholarship information.", "error");
    return;
  }

  const scholarship = {
    id: editingId || uid("scholarship"),
    name,
    provider,
    amount,
    slots,
    status
  };

  if (editingId) {
    const index = store.scholarships.findIndex(s => s.id === editingId);
    store.scholarships[index] = scholarship;
    showMessage(message, "Scholarship updated successfully.");
  } else {
    store.scholarships.push(scholarship);
    showMessage(message, "Scholarship added successfully.");
  }

  saveStore();
  resetForm();
  renderScholarships();
});

document.getElementById("cancelEdit").addEventListener("click", resetForm);
search.addEventListener("input", renderScholarships);

renderScholarships();
